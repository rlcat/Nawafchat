// =========================================================
// app.js
// نقطة الدخول الرئيسية: يربط auth.js وfirestore.js وui.js معًا،
// ويدير حالة التطبيق والتنقل بين الشاشات.
// =========================================================

import { login, logout, watchAuthState, markOfflineOnUnload } from "./auth.js";
import {
  listenUsers,
  listenUserDoc,
  listenConversationsForUser,
  getOrCreateConversation,
  markConversationRead,
  listenMessages,
  sendMessage,
  setTyping,
} from "./firestore.js";
import {
  showScreen,
  renderConversationsList,
  renderChatHeader,
  renderMessages,
  showError,
  hideError,
  applyTheme,
  preferredTheme,
  scrollToBottom,
} from "./ui.js";

/* ---------------------- عناصر DOM ---------------------- */

const el = {
  loginForm: document.getElementById("login-form"),
  loginEmail: document.getElementById("login-email"),
  loginPassword: document.getElementById("login-password"),
  loginError: document.getElementById("login-error"),
  loginSubmit: document.getElementById("login-submit"),
  loginSubmitLabel: document.getElementById("login-submit-label"),

  conversationsList: document.getElementById("conversations-list"),
  navButtons: document.querySelectorAll("[data-nav]"),

  chatBack: document.getElementById("chat-back-btn"),
  chatAvatar: document.getElementById("chat-header-avatar"),
  chatName: document.getElementById("chat-header-name"),
  chatStatus: document.getElementById("chat-header-status"),
  messagesWrap: document.getElementById("messages-wrap"),
  composerForm: document.getElementById("composer-form"),
  composerInput: document.getElementById("composer-input"),
  sendBtn: document.getElementById("send-btn"),

  settingsAvatar: document.getElementById("settings-avatar"),
  settingsName: document.getElementById("settings-name"),
  settingsEmail: document.getElementById("settings-email"),
  themeSwitch: document.getElementById("theme-switch"),
  logoutBtn: document.getElementById("logout-btn"),
};

/* ---------------------- الحالة العامة ---------------------- */

const state = {
  currentUser: null, // { uid, email, ... } من Firebase Auth
  currentUserDoc: null, // مستند users/{uid}
  users: [],
  conversationsByOtherUid: new Map(),
  activeChatUser: null,
  currentMessages: [],
  unsubUsers: null,
  unsubConvs: null,
  unsubMessages: null,
  unsubOtherUserDoc: null,
  typingTimeout: null,
  typingWatchInterval: null,
};

/* ---------------------- السمة ---------------------- */

applyTheme(preferredTheme());
syncThemeSwitch();

function syncThemeSwitch() {
  const isDark = document.body.getAttribute("data-theme") === "dark";
  el.themeSwitch.classList.toggle("on", isDark);
}

el.themeSwitch.addEventListener("click", () => {
  const next = document.body.getAttribute("data-theme") === "dark" ? "light" : "dark";
  applyTheme(next);
  syncThemeSwitch();
});

/* ---------------------- تسجيل الدخول ---------------------- */

el.loginForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  hideError(el.loginError);

  const email = el.loginEmail.value.trim();
  const password = el.loginPassword.value;

  if (!email || !password) {
    showError(el.loginError, "الرجاء إدخال البريد الإلكتروني وكلمة المرور.");
    return;
  }

  setLoginLoading(true);
  try {
    await login(email, password);
    // watchAuthState سيتولى الانتقال للصفحة الرئيسية تلقائيًا
    el.loginPassword.value = "";
  } catch (err) {
    showError(el.loginError, err.message || "تعذر تسجيل الدخول.");
  } finally {
    setLoginLoading(false);
  }
});

function setLoginLoading(loading) {
  el.loginSubmit.disabled = loading;
  el.loginSubmitLabel.innerHTML = loading
    ? `<span class="spinner"></span>`
    : "تسجيل الدخول";
}

/* ---------------------- تسجيل الخروج ---------------------- */

el.logoutBtn.addEventListener("click", async () => {
  el.logoutBtn.disabled = true;
  el.logoutBtn.textContent = "جارٍ تسجيل الخروج…";
  try {
    await logout();
  } finally {
    el.logoutBtn.disabled = false;
    el.logoutBtn.textContent = "تسجيل الخروج";
  }
});

/* ---------------------- التنقل السفلي ---------------------- */

el.navButtons.forEach((btn) => {
  btn.addEventListener("click", () => {
    const target = btn.dataset.nav;
    el.navButtons.forEach((b) => b.classList.toggle("active", b.dataset.nav === target));
    if (target === "home") showScreen("screen-home");
    if (target === "settings") showScreen("screen-settings");
  });
});

/* ---------------------- حالة المصادقة ---------------------- */

watchAuthState(onSignedIn, onSignedOut);
markOfflineOnUnload();

function onSignedIn(user) {
  state.currentUser = user;
  showScreen("screen-home");

  // مراقبة مستند المستخدم الحالي (للاستخدام في شاشة الإعدادات)
  if (state.unsubOtherUserDoc) state.unsubOtherUserDoc();
  listenUserDoc(user.uid, (docData) => {
    state.currentUserDoc = docData;
    renderSettingsProfile();
  });

  // مراقبة كل المستخدمين المصرح لهم
  if (state.unsubUsers) state.unsubUsers();
  state.unsubUsers = listenUsers(user.uid, (users) => {
    state.users = users;
    renderHomeList();
  });

  // مراقبة محادثات المستخدم الحالي
  if (state.unsubConvs) state.unsubConvs();
  state.unsubConvs = listenConversationsForUser(user.uid, (convs) => {
    state.conversationsByOtherUid = new Map();
    convs.forEach((c) => {
      const otherUid = c.members.find((m) => m !== user.uid);
      if (otherUid) state.conversationsByOtherUid.set(otherUid, c);
    });
    renderHomeList();
    // إن كانت محادثة مفتوحة حاليًا، حدّث مؤشر الكتابة من بيانات المحادثة
    if (state.activeChatUser) renderChatBody();
  });
}

function onSignedOut() {
  state.currentUser = null;
  state.currentUserDoc = null;
  state.users = [];
  state.conversationsByOtherUid = new Map();

  if (state.unsubUsers) state.unsubUsers();
  if (state.unsubConvs) state.unsubConvs();
  closeActiveChat();

  hideError(el.loginError);
  el.loginEmail.value = "";
  el.loginPassword.value = "";
  showScreen("screen-login");
}

/* ---------------------- الصفحة الرئيسية ---------------------- */

function renderHomeList() {
  if (!state.currentUser) return;
  renderConversationsList(
    el.conversationsList,
    state.users,
    state.conversationsByOtherUid,
    state.currentUser.uid,
    openChat
  );
}

/* ---------------------- شاشة المحادثة ---------------------- */

let activeConvId = null;

async function openChat(user) {
  state.activeChatUser = user;
  state.currentMessages = [];
  activeConvId = null;

  renderChatHeader(
    { avatarEl: el.chatAvatar, nameEl: el.chatName, statusEl: el.chatStatus },
    user,
    false
  );
  el.messagesWrap.innerHTML = "";
  showScreen("screen-chat");

  const convId = await getOrCreateConversation(state.currentUser.uid, user.uid);
  activeConvId = convId;

  await markConversationRead(convId, state.currentUser.uid);

  if (state.unsubMessages) state.unsubMessages();
  state.unsubMessages = listenMessages(convId, (messages) => {
    state.currentMessages = messages;
    renderChatBody();
    // أي رسالة جديدة تصل أثناء فتح المحادثة تُعتبر مقروءة فورًا
    markConversationRead(convId, state.currentUser.uid);
  });

  if (state.unsubOtherUserDoc) state.unsubOtherUserDoc();
  state.unsubOtherUserDoc = listenUserDoc(user.uid, (docData) => {
    state.activeChatUser = docData;
    renderChatBody();
    renderChatHeader(
      { avatarEl: el.chatAvatar, nameEl: el.chatName, statusEl: el.chatStatus },
      docData,
      isOtherUserTyping()
    );
  });

  // مؤشر "يكتب الآن…" له صلاحية مؤقتة (٦ ثوانٍ) ويجب أن يختفي تلقائيًا
  // حتى لو لم تصل أي رسالة أو تحديث جديد من Firestore أثناء تلك الفترة.
  clearInterval(state.typingWatchInterval);
  state.typingWatchInterval = setInterval(() => {
    if (activeConvId) renderChatBody();
  }, 2000);
}

/**
 * يعيد رسم منطقة الرسائل بأكملها (شامل مؤشر الكتابة) بأحدث حالة
 * معروفة، سواء تغيّرت الرسائل نفسها أو فقط حالة "يكتب الآن…".
 */
function renderChatBody() {
  const otherTyping = isOtherUserTyping();
  renderMessages(el.messagesWrap, state.currentMessages, state.currentUser.uid, otherTyping);
  scrollToBottom(el.messagesWrap);
  if (el.chatStatus && state.activeChatUser) {
    renderChatHeader(
      { avatarEl: el.chatAvatar, nameEl: el.chatName, statusEl: el.chatStatus },
      state.activeChatUser,
      otherTyping
    );
  }
}

function isOtherUserTyping() {
  if (!state.activeChatUser || !activeConvId) return false;
  const conv = state.conversationsByOtherUid.get(state.activeChatUser.uid);
  const typingTs = conv?.typing?.[state.activeChatUser.uid];
  if (!typingTs) return false;
  const ms = typingTs.toMillis ? typingTs.toMillis() : 0;
  // نعتبر المستخدم "يكتب" إن كان آخر تحديث خلال آخر 6 ثوانٍ فقط
  return Date.now() - ms < 6000;
}

el.chatBack.addEventListener("click", () => {
  closeActiveChat();
  showScreen("screen-home");
});

function closeActiveChat() {
  state.activeChatUser = null;
  state.currentMessages = [];
  activeConvId = null;
  clearInterval(state.typingWatchInterval);
  if (state.unsubMessages) state.unsubMessages();
  if (state.unsubOtherUserDoc) state.unsubOtherUserDoc();
}

/* ---------------------- إرسال الرسائل ---------------------- */

el.composerInput.addEventListener("input", () => {
  el.sendBtn.disabled = !el.composerInput.value.trim();
  autoGrow(el.composerInput);
  handleTypingSignal();
});

function autoGrow(textarea) {
  textarea.style.height = "auto";
  textarea.style.height = Math.min(textarea.scrollHeight, 120) + "px";
}

let lastTypingSentAt = 0;
function handleTypingSignal() {
  if (!activeConvId || !state.currentUser) return;
  const now = Date.now();
  if (now - lastTypingSentAt > 2000) {
    lastTypingSentAt = now;
    setTyping(activeConvId, state.currentUser.uid, true);
  }
  clearTimeout(state.typingTimeout);
  state.typingTimeout = setTimeout(() => {
    if (activeConvId) setTyping(activeConvId, state.currentUser.uid, false);
  }, 3000);
}

// إبقاء مربع الكتابة وآخر رسالة ظاهرين فوق لوحة المفاتيح في iOS Safari،
// التي لا "تدفع" الصفحة دائمًا بشكل موثوق مع position: sticky/fixed.
if (window.visualViewport) {
  window.visualViewport.addEventListener("resize", () => {
    const chatScreen = document.getElementById("screen-chat");
    if (!chatScreen.classList.contains("active")) return;
    requestAnimationFrame(() => {
      scrollToBottom(el.messagesWrap);
    });
  });
}

el.composerInput.addEventListener("focus", () => {
  setTimeout(() => scrollToBottom(el.messagesWrap), 250);
});

el.composerForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  const text = el.composerInput.value;
  if (!text.trim() || !activeConvId || !state.activeChatUser) return;

  el.composerInput.value = "";
  el.sendBtn.disabled = true;
  autoGrow(el.composerInput);
  clearTimeout(state.typingTimeout);
  setTyping(activeConvId, state.currentUser.uid, false);

  try {
    await sendMessage(activeConvId, state.currentUser.uid, state.activeChatUser.uid, text);
  } catch (err) {
    console.error("sendMessage error:", err);
    // أعد النص للمربع إن فشل الإرسال حتى لا يفقده المستخدم
    el.composerInput.value = text;
    el.sendBtn.disabled = false;
  }
});

/* ---------------------- شاشة الإعدادات ---------------------- */

function renderSettingsProfile() {
  if (!state.currentUserDoc) return;
  const { name, email, photoURL } = state.currentUserDoc;
  el.settingsAvatar.textContent = photoURL ? "" : (name?.charAt(0) || "؟").toUpperCase();
  if (photoURL) {
    el.settingsAvatar.innerHTML = `<img src="${photoURL}" alt="" />`;
  }
  el.settingsName.textContent = name || "—";
  el.settingsEmail.textContent = email || state.currentUser?.email || "—";
}

/* ---------------------- تسجيل Service Worker ---------------------- */

if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("./service-worker.js").catch((err) => {
      console.warn("تعذر تسجيل Service Worker:", err);
    });
  });
}

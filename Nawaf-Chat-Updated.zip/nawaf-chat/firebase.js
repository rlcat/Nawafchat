// =========================================================
// firebase.js
// تهيئة Firebase وتصدير الخدمات المستخدمة في بقية التطبيق.
//
// ضع بيانات مشروعك من Firebase Console هنا (Project settings → General
// → Your apps → SDK setup and configuration). هذه القيم "عامة" وليست
// كلمات مرور، لكن يجب أن يبقى الوصول الفعلي للبيانات محميًا عبر
// Firestore Security Rules (انظر firestore.rules)، وليس عبر إخفاء
// هذه القيم.
// =========================================================

import { initializeApp } from "https://www.gstatic.com/firebasejs/10.13.0/firebase-app.js";
import {
  getAuth,
  setPersistence,
  browserLocalPersistence,
} from "https://www.gstatic.com/firebasejs/10.13.0/firebase-auth.js";
import {
  getFirestore,
  initializeFirestore,
  persistentLocalCache,
  persistentSingleTabManager,
} from "https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js";

// -----------------------------------------------------
// ⚠️ استبدل القيم التالية ببيانات مشروعك في Firebase Console
// -----------------------------------------------------
export const firebaseConfig = {
  apiKey: "YOUR_FIREBASE_CONFIG_HERE",
  authDomain: "YOUR_FIREBASE_CONFIG_HERE",
  projectId: "YOUR_FIREBASE_CONFIG_HERE",
  storageBucket: "YOUR_FIREBASE_CONFIG_HERE",
  messagingSenderId: "YOUR_FIREBASE_CONFIG_HERE",
  appId: "YOUR_FIREBASE_CONFIG_HERE",
};

export const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);
// حافظ على الجلسة بين الزيارات (تسجيل دخول تلقائي حتى تسجيل الخروج يدويًا)
setPersistence(auth, browserLocalPersistence).catch((err) => {
  console.warn("تعذر ضبط نوع حفظ الجلسة:", err);
});

// Firestore مع تفعيل التخزين المحلي (يساعد على سرعة التحميل وعمل
// التطبيق بشكل جزئي أثناء انقطاع الشبكة القصير). لا تُستخدم هذه
// الذاكرة المحلية لتخزين بيانات حساسة بشكل دائم خارج جهاز المستخدم.
export let db;
try {
  db = initializeFirestore(app, {
    localCache: persistentLocalCache({ tabManager: persistentSingleTabManager({}) }),
  });
} catch (err) {
  // يحدث هذا عادة إذا كانت هناك عدة تبويبات مفتوحة، أو المتصفح لا يدعم IndexedDB
  console.warn("تعذر تفعيل التخزين المحلي لـ Firestore، سيتم المتابعة بدونه:", err);
  db = getFirestore(app);
}

// -----------------------------------------------------
// Firebase Cloud Messaging (اختياري - يعمل فقط إذا:
// 1) كان المتصفح يدعم Push API (Safari على iOS 16.4+ داخل PWA مضافة
//    للشاشة الرئيسية فقط، وليس داخل تبويب Safari العادي).
// 2) أضفت مفتاح VAPID الخاص بك من Firebase Console → Cloud Messaging.
// إن لم تحتَج الإشعارات الآن، تجاهل هذا الجزء بأمان دون كسر التطبيق.
// -----------------------------------------------------
export async function getMessagingIfSupported() {
  try {
    const { isSupported, getMessaging } = await import(
      "https://www.gstatic.com/firebasejs/10.13.0/firebase-messaging.js"
    );
    const supported = await isSupported();
    if (!supported) return null;
    return getMessaging(app);
  } catch (err) {
    console.warn("FCM غير مدعوم في هذه البيئة:", err);
    return null;
  }
}

export const VAPID_KEY = "YOUR_FIREBASE_CONFIG_HERE";

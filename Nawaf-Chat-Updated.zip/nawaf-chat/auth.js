// =========================================================
// auth.js
// كل ما يتعلق بتسجيل الدخول والخروج وحالة الجلسة.
// لا توجد صفحة أو دالة لإنشاء حساب جديد بتصميم متعمد: الحسابات
// العشرة تُنشأ يدويًا من Firebase Console فقط (انظر README.md).
// =========================================================

import { auth, db } from "./firebase.js";
import {
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
} from "https://www.gstatic.com/firebasejs/10.13.0/firebase-auth.js";
import { doc, getDoc, setDoc, serverTimestamp } from "https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js";

/**
 * رسائل الخطأ الخاصة بـ Firebase Auth مترجمة لرسائل عربية واضحة.
 * لا نكشف تفاصيل تقنية للمستخدم النهائي.
 */
function translateAuthError(error) {
  const code = error?.code || "";
  const map = {
    "auth/invalid-email": "صيغة البريد الإلكتروني غير صحيحة.",
    "auth/user-disabled": "تم تعطيل هذا الحساب. تواصل مع مدير التطبيق.",
    "auth/user-not-found": "البريد الإلكتروني أو كلمة المرور غير صحيحة.",
    "auth/wrong-password": "البريد الإلكتروني أو كلمة المرور غير صحيحة.",
    "auth/invalid-credential": "البريد الإلكتروني أو كلمة المرور غير صحيحة.",
    "auth/too-many-requests": "محاولات كثيرة جدًا. الرجاء الانتظار قليلًا ثم المحاولة مجددًا.",
    "auth/network-request-failed": "تعذر الاتصال بالشبكة. تحقق من اتصالك بالإنترنت.",
    "auth/unauthorized-domain": "نطاق الموقع غير مصرح له في إعدادات Firebase. أضِفه من Authentication → Settings → Authorized domains.",
  };
  return map[code] || "تعذر تسجيل الدخول. حاول مرة أخرى.";
}

/**
 * تسجيل الدخول عبر البريد وكلمة المرور فقط.
 * يرمي خطأ برسالة عربية جاهزة للعرض عند الفشل.
 */
export async function login(email, password) {
  try {
    const cred = await signInWithEmailAndPassword(auth, email.trim(), password);

    // بعد نجاح المصادقة، تأكد من وجود مستند المستخدم في users/{uid}.
    // ملاحظة أمنية: هذا لا يمنح صلاحية بحد ذاته — التحقق الفعلي من أن
    // الحساب من ضمن الحسابات العشرة المصرح لها يتم عبر Firestore
    // Security Rules (طلب Firestore سيُرفض تلقائيًا لأي UID غير مدرج
    // هناك، بغض النظر عمّا يحدث في هذا الملف).
    const userRef = doc(db, "users", cred.user.uid);
    const snap = await getDoc(userRef);
    if (!snap.exists()) {
      await setDoc(userRef, {
        name: cred.user.displayName || cred.user.email.split("@")[0],
        email: cred.user.email,
        photoURL: cred.user.photoURL || "",
        online: true,
        lastSeen: serverTimestamp(),
      });
    } else {
      await setDoc(userRef, { online: true, lastSeen: serverTimestamp() }, { merge: true });
    }

    return cred.user;
  } catch (error) {
    // إذا رفضت Security Rules كتابة users/{uid} لأن هذا الحساب غير
    // مُدرج ضمن العشرة، تصل رسالة "permission-denied" هنا.
    if (error?.code === "permission-denied") {
      await signOut(auth);
      throw new Error("هذا الحساب غير مصرح له باستخدام التطبيق.");
    }
    throw new Error(translateAuthError(error));
  }
}

/**
 * تسجيل الخروج، مع تحديث حالة "غير متصل" قبل إنهاء الجلسة.
 */
export async function logout() {
  const user = auth.currentUser;
  try {
    if (user) {
      const userRef = doc(db, "users", user.uid);
      await setDoc(userRef, { online: false, lastSeen: serverTimestamp() }, { merge: true }).catch(() => {});
    }
  } finally {
    await signOut(auth);
  }
}

/**
 * الاستماع لتغيّر حالة تسجيل الدخول (تُستخدم لعرض الشاشة المناسبة
 * تلقائيًا عند فتح التطبيق، وللحفاظ على الجلسة بين الزيارات).
 */
export function watchAuthState(onUser, onGuest) {
  return onAuthStateChanged(auth, (user) => {
    if (user) onUser(user);
    else onGuest();
  });
}

/**
 * يُنادى عند إغلاق التطبيق/التبويب لتحديث حالة الاتصال قدر الإمكان.
 * (غير مضمون 100% في iOS Safari، لذلك نعتمد أيضًا على lastSeen كخط دفاع ثانٍ)
 */
export function markOfflineOnUnload() {
  window.addEventListener("pagehide", () => {
    const user = auth.currentUser;
    if (!user) return;
    const userRef = doc(db, "users", user.uid);
    setDoc(userRef, { online: false, lastSeen: serverTimestamp() }, { merge: true }).catch(() => {});
  });
}

// =========================================================
// ui.js
// دوال مساعدة لعرض الواجهة فقط — لا تحتوي منطق مصادقة أو قواعد بيانات.
// =========================================================

/* ---------------------- التنقل بين الشاشات ---------------------- */

const SCREEN_IDS = ["screen-boot", "screen-login", "screen-home", "screen-chat", "screen-settings"];

export function showScreen(id) {
  SCREEN_IDS.forEach((sid) => {
    const el = document.getElementById(sid);
    if (!el) return;
    el.classList.toggle("active", sid === id);
  });
}

/* ---------------------- تنسيق الوقت ---------------------- */

export function formatMessageTime(ts) {
  const date = ts?.toDate ? ts.toDate() : ts instanceof Date ? ts : null;
  if (!date) return "";
  return date.toLocaleTimeString("ar-SA", { hour: "2-digit", minute: "2-digit" });
}

export function formatListTime(ts) {
  const date = ts?.toDate ? ts.toDate() : ts instanceof Date ? ts : null;
  if (!date) return "";
  const now = new Date();
  const sameDay = date.toDateString() === now.toDateString();
  if (sameDay) return date.toLocaleTimeString("ar-SA", { hour: "2-digit", minute: "2-digit" });
  const yesterday = new Date(now);
  yesterday.setDate(now.getDate() - 1);
  if (date.toDateString() === yesterday.toDateString()) return "أمس";
  return date.toLocaleDateString("ar-SA", { day: "numeric", month: "short" });
}

export function formatDayDivider(ts) {
  const date = ts?.toDate ? ts.toDate() : ts instanceof Date ? ts : null;
  if (!date) return "";
  const now = new Date();
  const sameDay = date.toDateString() === now.toDateString();
  if (sameDay) return "اليوم";
  const yesterday = new Date(now);
  yesterday.setDate(now.getDate() - 1);
  if (date.toDateString() === yesterday.toDateString()) return "أمس";
  return date.toLocaleDateString("ar-SA", { day: "numeric", month: "long", year: "numeric" });
}

/* ---------------------- أدوات نصية ---------------------- */

export function initials(name) {
  if (!name) return "؟";
  const parts = name.trim().split(/\s+/);
  return parts[0]?.charAt(0)?.toUpperCase() || "؟";
}

function escapeHTML(str) {
  const div = document.createElement("div");
  div.textContent = str ?? "";
  return div.innerHTML;
}

/* ---------------------- عرض قائمة المحادثات ---------------------- */

/**
 * users: كل المستخدمين المصرح لهم عدا الحالي
 * conversationsByOtherUid: خريطة uid المستخدم الآخر → مستند المحادثة
 */
export function renderConversationsList(container, users, conversationsByOtherUid, currentUid, onOpen) {
  container.innerHTML = "";

  if (!users.length) {
    container.innerHTML = `
      <div class="empty-state">
        <div class="big">لا يوجد مستخدمون بعد</div>
        <div class="small">أضِف الحسابات من Firebase Console.</div>
      </div>`;
    return;
  }

  // ترتيب: من لديه رسالة أحدث أولًا، ثم البقية أبجديًا
  const sorted = [...users].sort((a, b) => {
    const ca = conversationsByOtherUid.get(a.uid);
    const cb = conversationsByOtherUid.get(b.uid);
    const ta = ca?.lastMessage?.createdAt?.toMillis?.() || 0;
    const tb = cb?.lastMessage?.createdAt?.toMillis?.() || 0;
    if (ta !== tb) return tb - ta;
    return (a.name || "").localeCompare(b.name || "", "ar");
  });

  sorted.forEach((user) => {
    const conv = conversationsByOtherUid.get(user.uid);
    const unread = conv?.unread?.[currentUid] || 0;
    const lastText = conv?.lastMessage?.text || "ابدأ المحادثة";
    const lastTime = conv?.lastMessage?.createdAt ? formatListTime(conv.lastMessage.createdAt) : "";

    const item = document.createElement("button");
    item.className = "conv-item";
    item.style.width = "100%";
    item.style.textAlign = "start";
    item.innerHTML = `
      <div class="avatar">
        ${user.photoURL ? `<img src="${escapeHTML(user.photoURL)}" alt="" />` : escapeHTML(initials(user.name))}
        <span class="presence-dot ${user.online ? "online" : ""}"></span>
      </div>
      <div class="conv-body">
        <div class="conv-row1">
          <span class="conv-name">${escapeHTML(user.name || user.email || "مستخدم")}</span>
          <span class="conv-time">${escapeHTML(lastTime)}</span>
        </div>
        <div class="conv-row2">
          <span class="conv-preview">${escapeHTML(lastText)}</span>
          ${unread > 0 ? `<span class="unread-badge">${unread > 99 ? "99+" : unread}</span>` : ""}
        </div>
      </div>
    `;
    item.addEventListener("click", () => onOpen(user));
    container.appendChild(item);
  });
}

/* ---------------------- عرض ترويسة المحادثة ---------------------- */

export function renderChatHeader({ avatarEl, nameEl, statusEl }, user, isTyping) {
  avatarEl.innerHTML = user.photoURL
    ? `<img src="${escapeHTML(user.photoURL)}" alt="" />`
    : escapeHTML(initials(user.name));
  nameEl.textContent = user.name || user.email || "مستخدم";

  if (isTyping) {
    statusEl.textContent = "يكتب الآن…";
    statusEl.classList.add("online");
  } else if (user.online) {
    statusEl.textContent = "متصل الآن";
    statusEl.classList.add("online");
  } else {
    statusEl.classList.remove("online");
    const lastSeenDate = user.lastSeen?.toDate ? user.lastSeen.toDate() : null;
    statusEl.textContent = lastSeenDate
      ? `آخر ظهور ${formatListTime(user.lastSeen)}`
      : "غير متصل";
  }
}

/* ---------------------- عرض فقاعات الرسائل ---------------------- */

export function renderMessages(container, messages, currentUid, isOtherTyping) {
  const wasAtBottom = isScrolledToBottom(container);
  container.innerHTML = "";

  let lastDayKey = null;

  messages.forEach((msg) => {
    const date = msg.createdAt?.toDate ? msg.createdAt.toDate() : new Date();
    const dayKey = date.toDateString();
    if (dayKey !== lastDayKey) {
      const divider = document.createElement("div");
      divider.className = "day-divider";
      divider.textContent = formatDayDivider(msg.createdAt);
      container.appendChild(divider);
      lastDayKey = dayKey;
    }

    const mine = msg.senderId === currentUid;
    const row = document.createElement("div");
    row.className = `msg-row ${mine ? "mine" : "theirs"}`;
    row.innerHTML = `
      <div class="bubble">
        ${escapeHTML(msg.text)}
        <span class="bubble-time">${escapeHTML(formatMessageTime(msg.createdAt))}</span>
      </div>
    `;
    container.appendChild(row);
  });

  if (isOtherTyping) {
    const typingRow = document.createElement("div");
    typingRow.className = "msg-row theirs";
    typingRow.innerHTML = `
      <div class="typing-indicator"><span></span><span></span><span></span></div>
    `;
    container.appendChild(typingRow);
  }

  if (wasAtBottom) scrollToBottom(container);
}

export function isScrolledToBottom(el, threshold = 120) {
  return el.scrollHeight - el.scrollTop - el.clientHeight < threshold;
}

export function scrollToBottom(el) {
  requestAnimationFrame(() => {
    el.scrollTop = el.scrollHeight;
  });
}

/* ---------------------- الأخطاء ---------------------- */

export function showError(el, message) {
  el.textContent = message;
  el.classList.add("show");
}

export function hideError(el) {
  el.classList.remove("show");
  el.textContent = "";
}

/* ---------------------- السمة (داكن/فاتح) ---------------------- */

const THEME_COLORS = { dark: "#0B1220", light: "#F6F4EF" };

export function applyTheme(theme) {
  document.body.setAttribute("data-theme", theme);

  const meta = document.getElementById("theme-color-meta");
  if (meta) meta.setAttribute("content", THEME_COLORS[theme] || THEME_COLORS.dark);

  try {
    localStorage.setItem("nawaf-theme", theme);
  } catch (err) {
    // بعض أوضاع التصفح الخاص في iOS تمنع localStorage — لا داعي لإيقاف التطبيق لهذا
    console.warn("تعذر حفظ تفضيل السمة:", err);
  }
}

export function getStoredTheme() {
  try {
    return localStorage.getItem("nawaf-theme");
  } catch (err) {
    return null;
  }
}

export function preferredTheme() {
  const stored = getStoredTheme();
  if (stored === "dark" || stored === "light") return stored;
  return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
}

// =========================================================
// firestore.js
// طبقة الوصول إلى البيانات: المستخدمون، المحادثات، الرسائل.
//
// بنية البيانات:
//   users/{uid}                → name, email, photoURL, online, lastSeen
//   conversations/{convId}     → members: [uidA, uidB], lastMessage,
//                                 unread: { [uid]: number }, typing: { [uid]: timestamp|null }
//   messages/{messageId}       → conversationId, senderId, text, createdAt
//
// معرّف المحادثة (convId) يُبنى من ضم الـ UID الأصغر أولًا فرزًا
// أبجديًا، حتى لا تُنشأ محادثتان مكررتان لنفس الشخصين:
//   convId = uidA < uidB ? `${uidA}_${uidB}` : `${uidB}_${uidA}`
// =========================================================

import { db } from "./firebase.js";
import {
  collection,
  doc,
  addDoc,
  setDoc,
  getDoc,
  updateDoc,
  query,
  where,
  orderBy,
  onSnapshot,
  serverTimestamp,
  increment,
  limit as fsLimit,
} from "https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js";

/* ---------------------- أدوات مساعدة ---------------------- */

export function buildConversationId(uidA, uidB) {
  return uidA < uidB ? `${uidA}_${uidB}` : `${uidB}_${uidA}`;
}

/* ---------------------- المستخدمون ---------------------- */

/**
 * الاستماع لكل المستخدمين المصرح لهم (الحسابات العشرة) عدا المستخدم
 * الحالي، لعرضهم في الصفحة الرئيسية. القائمة الفعلية للحسابات
 * المسموح بها محكومة عبر Security Rules، لا عبر هذا الاستعلام.
 */
export function listenUsers(currentUid, callback) {
  const q = query(collection(db, "users"), orderBy("name", "asc"));
  return onSnapshot(
    q,
    (snap) => {
      const users = [];
      snap.forEach((d) => {
        if (d.id === currentUid) return;
        users.push({ uid: d.id, ...d.data() });
      });
      callback(users);
    },
    (err) => console.error("listenUsers error:", err)
  );
}

export function listenUserDoc(uid, callback) {
  return onSnapshot(doc(db, "users", uid), (snap) => {
    if (snap.exists()) callback({ uid: snap.id, ...snap.data() });
  });
}

/* ---------------------- المحادثات ---------------------- */

/**
 * إنشاء محادثة إن لم تكن موجودة، أو إعادة معرّفها إن كانت موجودة.
 */
export async function getOrCreateConversation(uidA, uidB) {
  const convId = buildConversationId(uidA, uidB);
  const ref = doc(db, "conversations", convId);
  const snap = await getDoc(ref);
  if (!snap.exists()) {
    await setDoc(ref, {
      members: [uidA, uidB],
      lastMessage: null,
      unread: { [uidA]: 0, [uidB]: 0 },
      typing: {},
      createdAt: serverTimestamp(),
    });
  }
  return convId;
}

/**
 * الاستماع لكل محادثات المستخدم الحالي، مرتّبة بحسب آخر رسالة.
 */
export function listenConversationsForUser(uid, callback) {
  const q = query(collection(db, "conversations"), where("members", "array-contains", uid));
  return onSnapshot(
    q,
    (snap) => {
      const list = [];
      snap.forEach((d) => list.push({ id: d.id, ...d.data() }));
      list.sort((a, b) => {
        const ta = a.lastMessage?.createdAt?.toMillis?.() || 0;
        const tb = b.lastMessage?.createdAt?.toMillis?.() || 0;
        return tb - ta;
      });
      callback(list);
    },
    (err) => console.error("listenConversationsForUser error:", err)
  );
}

/**
 * تصفير عدّاد غير المقروء للمستخدم الحالي عند فتح المحادثة.
 */
export async function markConversationRead(convId, uid) {
  const ref = doc(db, "conversations", convId);
  await updateDoc(ref, { [`unread.${uid}`]: 0 }).catch((err) =>
    console.warn("markConversationRead:", err)
  );
}

/**
 * تحديث مؤشر "يكتب الآن…" لمستخدم داخل محادثة معيّنة.
 */
export async function setTyping(convId, uid, isTyping) {
  const ref = doc(db, "conversations", convId);
  await updateDoc(ref, {
    [`typing.${uid}`]: isTyping ? serverTimestamp() : null,
  }).catch(() => {});
}

/* ---------------------- الرسائل ---------------------- */

/**
 * الاستماع لآخر رسائل محادثة معيّنة (بحد أقصى لأداء أفضل، مع إمكانية
 * لاحقًا لتحميل المزيد عبر التمرير للأعلى).
 */
export function listenMessages(convId, callback, max = 200) {
  const q = query(
    collection(db, "messages"),
    where("conversationId", "==", convId),
    orderBy("createdAt", "asc"),
    fsLimit(max)
  );
  return onSnapshot(
    q,
    (snap) => {
      const list = [];
      snap.forEach((d) => list.push({ id: d.id, ...d.data() }));
      callback(list);
    },
    (err) => console.error("listenMessages error:", err)
  );
}

/**
 * إرسال رسالة نصية، وتحديث lastMessage وعدّاد غير المقروء للطرف الآخر.
 *
 * البنية جاهزة لإضافة الصور/الملفات لاحقًا: يكفي إضافة الحقول
 * الاختيارية mediaURL / mediaType / fileName إلى مستند الرسالة،
 * وتحديث render في ui.js لعرضها.
 */
export async function sendMessage(convId, senderId, recipientId, text) {
  const trimmed = text.trim();
  if (!trimmed) return;

  await addDoc(collection(db, "messages"), {
    conversationId: convId,
    senderId,
    text: trimmed,
    // جاهز للتوسعة لاحقًا لدعم الوسائط:
    mediaURL: null,
    mediaType: null,
    createdAt: serverTimestamp(),
  });

  const convRef = doc(db, "conversations", convId);
  await updateDoc(convRef, {
    lastMessage: { text: trimmed, senderId, createdAt: serverTimestamp() },
    [`unread.${recipientId}`]: increment(1),
    [`typing.${senderId}`]: null,
  });
}

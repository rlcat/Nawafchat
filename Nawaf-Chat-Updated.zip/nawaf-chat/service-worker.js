// =========================================================
// service-worker.js
// يخزّن فقط ملفات الواجهة الثابتة (Shell) لتشغيل سريع وعمل جزئي
// دون اتصال. لا يخزّن مطلقًا استجابات Firebase/Firestore/Auth، ولا
// أي بيانات محادثات أو مستخدمين — هذه تُجلب دائمًا مباشرة من الشبكة
// عبر Firebase SDK ولا تمر عبر هذا الـ Service Worker أصلًا (لأنها
// تعتمد WebChannel/WebSocket وليست طلبات fetch عادية قابلة للاعتراض
// بنفس الطريقة، ونستثنيها صراحة أدناه للاحتياط).
// =========================================================

const CACHE_NAME = "nawaf-chat-shell-v1";

const SHELL_FILES = [
  "./",
  "./index.html",
  "./style.css",
  "./app.js",
  "./firebase.js",
  "./auth.js",
  "./firestore.js",
  "./ui.js",
  "./manifest.json",
  "./icons/icon-192.png",
  "./icons/icon-512.png",
];

// نطاقات لا يجب تخزينها مؤقتًا مطلقًا (مصادقة/بيانات/شبكات جوجل)
const NEVER_CACHE_HOSTS = [
  "firestore.googleapis.com",
  "identitytoolkit.googleapis.com",
  "securetoken.googleapis.com",
  "firebaseinstallations.googleapis.com",
  "fcmregistrations.googleapis.com",
  "googleapis.com",
  "gstatic.com",
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches
      .open(CACHE_NAME)
      .then((cache) => cache.addAll(SHELL_FILES))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) =>
        Promise.all(keys.filter((key) => key !== CACHE_NAME).map((key) => caches.delete(key)))
      )
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (event) => {
  const url = new URL(event.request.url);

  // لا تتدخل إطلاقًا في طلبات المصادقة/قاعدة البيانات/مكتبات Firebase
  if (NEVER_CACHE_HOSTS.some((host) => url.hostname.includes(host))) {
    return;
  }

  // فقط GET قابلة للتخزين المؤقت
  if (event.request.method !== "GET") return;

  event.respondWith(
    caches.match(event.request).then((cached) => {
      const networkFetch = fetch(event.request)
        .then((response) => {
          if (response && response.status === 200 && response.type === "basic") {
            const clone = response.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(event.request, clone));
          }
          return response;
        })
        .catch(() => cached);

      // Cache-first لسرعة الفتح، مع تحديث الكاش في الخلفية
      return cached || networkFetch;
    })
  );
});

// دعم اختياري لإشعارات Push عبر FCM (يعمل فقط بعد إضافة Firebase
// Messaging config الحقيقي في firebase.js وتفعيل الإذن من المستخدم)
self.addEventListener("push", (event) => {
  if (!event.data) return;
  let payload = {};
  try {
    payload = event.data.json();
  } catch (err) {
    return;
  }
  const title = payload.notification?.title || "Nawaf Chat";
  const options = {
    body: payload.notification?.body || "",
    icon: "./icons/icon-192.png",
    badge: "./icons/icon-192.png",
    dir: "rtl",
    lang: "ar",
  };
  event.waitUntil(self.registration.showNotification(title, options));
});

self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  event.waitUntil(
    self.clients.matchAll({ type: "window" }).then((clientsArr) => {
      const existing = clientsArr.find((c) => "focus" in c);
      if (existing) return existing.focus();
      return self.clients.openWindow("./index.html");
    })
  );
});
